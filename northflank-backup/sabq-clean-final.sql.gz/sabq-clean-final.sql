-- SABQ Database - Clean PostgreSQL Import
-- Created: 2025-08-31T00:00:00.000Z
-- Fixed: Column name mapping and data compatibility
-- Target: Northflank PostgreSQL Database

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

BEGIN;

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- Clean table creation with proper PostgreSQL syntax
CREATE TABLE IF NOT EXISTS "users" (
    id text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    email text UNIQUE,
    password text,
    name text,
    avatar text,
    role text DEFAULT 'user',
    is_admin boolean DEFAULT false,
    is_verified boolean DEFAULT false,
    verification_token text,
    reset_token text,
    reset_token_expiry timestamp,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp DEFAULT CURRENT_TIMESTAMP,
    city text,
    country text DEFAULT 'SA',
    date_of_birth date,
    email_verified_at timestamp,
    gender text,
    interests jsonb DEFAULT '[]'::jsonb,
    last_login_at timestamp,
    loyalty_points integer DEFAULT 0,
    notification_preferences jsonb DEFAULT '{"sms":false,"push":false,"email":true}'::jsonb,
    phone text,
    preferred_language text DEFAULT 'ar',
    profile_completed boolean DEFAULT false,
    status text DEFAULT 'active',
    two_factor_enabled boolean DEFAULT false
);

CREATE TABLE IF NOT EXISTS "categories" (
    id serial PRIMARY KEY,
    name_ar text NOT NULL,
    name_en text NOT NULL,
    slug text UNIQUE NOT NULL,
    description text,
    color text DEFAULT '#3B82F6',
    icon text,
    is_active boolean DEFAULT true,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp DEFAULT CURRENT_TIMESTAMP,
    parent_id integer REFERENCES categories(id)
);

CREATE TABLE IF NOT EXISTS "articles" (
    id serial PRIMARY KEY,
    title text NOT NULL,
    content text,
    excerpt text,
    slug text UNIQUE NOT NULL,
    featured_image text,
    published_at timestamp,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp DEFAULT CURRENT_TIMESTAMP,
    author_id text NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    category_id integer REFERENCES categories(id),
    status text DEFAULT 'draft',
    view_count integer DEFAULT 0,
    like_count integer DEFAULT 0,
    comment_count integer DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT true,
    is_featured boolean DEFAULT false,
    reading_time integer DEFAULT 0,
    tags text[]
);

CREATE TABLE IF NOT EXISTS "comments" (
    id text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    article_id text NOT NULL,
    user_id text,
    parent_id text,
    content text NOT NULL,
    status text DEFAULT 'pending',
    likes integer DEFAULT 0,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP,
    updated_at timestamp DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "tags" (
    id serial PRIMARY KEY,
    name text UNIQUE NOT NULL,
    slug text UNIQUE NOT NULL,
    color text DEFAULT '#6B7280',
    created_at timestamp DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "article_tags" (
    id serial PRIMARY KEY,
    article_id integer REFERENCES articles(id) ON DELETE CASCADE,
    tag_id integer REFERENCES tags(id) ON DELETE CASCADE,
    created_at timestamp DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(article_id, tag_id)
);

-- Sample data with proper column mapping
INSERT INTO "users" VALUES 
('84a37981-3a15-4810-90e1-e17baa3550d7', 'admin@sabq.ai', '$2b$12$lca7iy2gSwTnsky7ocDXvuO4F0nkpPFn4kvoBRtO1CR4pLcmLxAnO', 'مدير النظام', 'https://res.cloudinary.com/dybhezmvb/image/upload/v1752348322/sabq-cms/avatars/1752348322798_untitleddesign.jpg_9o77i4.jpg', 'admin', true, true, NULL, NULL, NULL, '2025-07-06T05:24:37.468Z', '2025-08-24T10:13:16.467Z', NULL, 'SA', NULL, NULL, NULL, '[]'::jsonb, '2025-08-23T15:33:21.130Z', 0, '{"sms":false,"push":false,"email":true}'::jsonb, NULL, 'ar', true, 'active', true),
('0f107dd1-bfb7-4fac-b664-6587e6fc9a1e', 'editor@sabq.ai', '$2b$10$RJSTzD9b6nH0/RTkufPCFuCVof8qT5rJAmo4ecg6ANZCP64dIDHN2', 'علي عبده', 'https://res.cloudinary.com/dybhezmvb/image/upload/v1755455249/sabq-cms/general/1755455249719_Screenshot_2025-08-17_at_9.27.16_PM.png.png', 'moderator', false, true, NULL, NULL, NULL, '2025-07-06T05:24:37.468Z', '2025-08-30T12:07:56.928Z', NULL, 'SA', NULL, NULL, NULL, '[]'::jsonb, '2025-08-30T12:07:56.928Z', 0, '{"sms":false,"push":false,"email":true}'::jsonb, NULL, 'ar', true, 'active', false),
('27e3bdc6-68a5-459a-9f11-15ddd9a46aac', 'user@sabq.ai', '$2b$10$RJSTzD9b6nH0/RTkufPCFuCVof8qT5rJAmo4ecg6ANZCP64dIDHN2', 'مستخدم تجريبي', NULL, 'user', false, true, NULL, NULL, NULL, '2025-07-06T05:24:37.468Z', '2025-08-27T04:07:12.519Z', NULL, 'SA', NULL, NULL, NULL, '[]'::jsonb, '2025-08-27T04:07:12.519Z', 0, '{"sms":false,"push":false,"email":true}'::jsonb, NULL, 'ar', true, 'active', false)
ON CONFLICT (id) DO NOTHING;

INSERT INTO "categories" (name_ar, name_en, slug, description, color) VALUES 
('رياضة', 'Sports', 'sports', 'أخبار رياضية وتغطيات شاملة', '#10B981'),
('تقنية', 'Technology', 'technology', 'آخر المستجدات التقنية والتكنولوجية', '#3B82F6'),
('صحة', 'Health', 'health', 'نصائح طبية وأخبار صحية', '#EF4444'),
('سياسة', 'Politics', 'politics', 'الأخبار السياسية والتحليلات', '#8B5CF6'),
('اقتصاد', 'Economy', 'economy', 'الأخبار الاقتصادية والمالية', '#F59E0B'),
('ثقافة', 'Culture', 'culture', 'الأخبار الثقافية والفنية', '#EC4899'),
('محلي', 'Local', 'local', 'الأخبار المحلية', '#06B6D4')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO "tags" (name, slug, color) VALUES 
('عاجل', 'urgent', '#EF4444'),
('حصري', 'exclusive', '#8B5CF6'),
('تحليل', 'analysis', '#059669'),
('رأي', 'opinion', '#DC2626'),
('تقرير', 'report', '#2563EB'),
('مقابلة', 'interview', '#7C3AED'),
('خبر', 'news', '#374151')
ON CONFLICT (slug) DO NOTHING;

INSERT INTO "articles" (title, content, excerpt, slug, author_id, category_id, status, view_count, like_count, published_at) VALUES 
('مرحبًا بكم في موقع سبق الإخباري', 'يسعدنا أن نقدم لكم موقع سبق الإخباري الجديد بتصميمه المتطور وإمكانياته المتقدمة. نحن نسعى لتقديم أفضل الأخبار والتقارير الحصرية لقرائنا الكرام.', 'موقع سبق الإخباري الجديد يقدم لكم أحدث الأخبار بتصميم متطور', 'welcome-to-sabq', '84a37981-3a15-4810-90e1-e17baa3550d7', 1, 'published', 125, 8, CURRENT_TIMESTAMP),
('التطورات التقنية في المملكة', 'تشهد المملكة العربية السعودية نقلة نوعية في مجال التكنولوجيا والتحول الرقمي، حيث تعمل رؤية 2030 على تطوير القطاع التقني بشكل كبير.', 'رؤية 2030 تقود التحول التقني في المملكة', 'tech-developments-ksa', '0f107dd1-bfb7-4fac-b664-6587e6fc9a1e', 2, 'published', 89, 12, CURRENT_TIMESTAMP),
('أهمية الصحة في حياتنا اليومية', 'تلعب الصحة دورًا مهمًا في حياتنا اليومية، ومن المهم الاهتمام بالغذاء الصحي والرياضة للحفاظ على نمط حياة سليم.', 'نصائح مهمة للحفاظ على الصحة العامة', 'daily-health-tips', '27e3bdc6-68a5-459a-9f11-15ddd9a46aac', 3, 'published', 67, 5, CURRENT_TIMESTAMP),
('الاقتصاد السعودي في نمو مستمر', 'يشهد الاقتصاد السعودي نموًا مطردًا بفضل الإصلاحات الاقتصادية والمشاريع الضخمة التي تنفذها المملكة ضمن رؤية 2030.', 'نمو الاقتصاد السعودي يحقق أرقامًا قياسية', 'saudi-economy-growth', '84a37981-3a15-4810-90e1-e17baa3550d7', 5, 'published', 156, 18, CURRENT_TIMESTAMP)
ON CONFLICT (slug) DO NOTHING;

-- Create sample comments
INSERT INTO "comments" (article_id, user_id, content, status) VALUES 
('1', '0f107dd1-bfb7-4fac-b664-6587e6fc9a1e', 'مقال ممتاز، شكرًا لكم على الجهود المبذولة', 'approved'),
('1', '27e3bdc6-68a5-459a-9f11-15ddd9a46aac', 'نتطلع للمزيد من هذا المحتوى القيم', 'approved'),
('2', '84a37981-3a15-4810-90e1-e17baa3550d7', 'التقنية تلعب دورًا محوريًا في التطوير', 'approved')
ON CONFLICT (id) DO NOTHING;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_articles_author ON articles(author_id);
CREATE INDEX IF NOT EXISTS idx_articles_category ON articles(category_id);
CREATE INDEX IF NOT EXISTS idx_articles_published ON articles(published_at);
CREATE INDEX IF NOT EXISTS idx_articles_slug ON articles(slug);
CREATE INDEX IF NOT EXISTS idx_articles_status ON articles(status);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_categories_slug ON categories(slug);
CREATE INDEX IF NOT EXISTS idx_comments_article ON comments(article_id);
CREATE INDEX IF NOT EXISTS idx_comments_user ON comments(user_id);

-- Update sequences to avoid conflicts
SELECT setval('categories_id_seq', COALESCE((SELECT MAX(id) FROM categories), 7));
SELECT setval('articles_id_seq', COALESCE((SELECT MAX(id) FROM articles), 4));
SELECT setval('tags_id_seq', COALESCE((SELECT MAX(id) FROM tags), 7));
SELECT setval('article_tags_id_seq', 1);

COMMIT;

-- Success notification
DO $$
BEGIN
    RAISE NOTICE '==============================================';
    RAISE NOTICE 'SABQ Database - CLEAN VERSION Completed!';
    RAISE NOTICE 'Tables: users, categories, articles, comments, tags';
    RAISE NOTICE 'Data: 3 users, 7 categories, 4 articles, 3 comments, 7 tags';
    RAISE NOTICE 'Fixed: All column mapping and PostgreSQL syntax';
    RAISE NOTICE 'Ready for production use!';
    RAISE NOTICE '==============================================';
END $$;
