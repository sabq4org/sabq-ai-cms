-- SABQ CMS - FIXED SYNTAX VERSION
-- Created: 2025-08-30
-- Purpose: Fix PostgreSQL syntax errors
-- Fix: integer(32,0) → integer

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

BEGIN;

-- ===========================================
-- FIXED SCHEMA (PostgreSQL compatible)
-- ===========================================

-- Users table (fixed syntax)
CREATE TABLE IF NOT EXISTS "users" (
    "id" text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "email" text UNIQUE NOT NULL,
    "name" text,
    "password" text,
    "image" text,
    "role" text DEFAULT 'USER',
    "createdAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "isActive" boolean DEFAULT true,
    "loyalty_points" integer DEFAULT 0,
    "bio" text,
    "location" text,
    "website" text
);

-- Categories table
CREATE TABLE IF NOT EXISTS "categories" (
    "id" serial PRIMARY KEY,
    "name" text NOT NULL,
    "slug" text UNIQUE NOT NULL,
    "description" text,
    "color" text DEFAULT '#3B82F6',
    "createdAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "isActive" boolean DEFAULT true,
    "parentId" integer REFERENCES "categories"("id") ON DELETE SET NULL
);

-- Articles table
CREATE TABLE IF NOT EXISTS "articles" (
    "id" serial PRIMARY KEY,
    "title" text NOT NULL,
    "content" text,
    "excerpt" text,
    "slug" text UNIQUE NOT NULL,
    "featuredImage" text,
    "publishedAt" timestamp(3),
    "createdAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "authorId" text REFERENCES "users"("id") ON DELETE CASCADE,
    "categoryId" integer REFERENCES "categories"("id") ON DELETE SET NULL,
    "status" text DEFAULT 'DRAFT',
    "viewCount" integer DEFAULT 0,
    "likeCount" integer DEFAULT 0,
    "commentCount" integer DEFAULT 0,
    "isActive" boolean DEFAULT true,
    "isFeatured" boolean DEFAULT false,
    "metadata" jsonb DEFAULT '{}'
);

-- Comments table
CREATE TABLE IF NOT EXISTS "comments" (
    "id" serial PRIMARY KEY,
    "content" text NOT NULL,
    "createdAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "authorId" text REFERENCES "users"("id") ON DELETE CASCADE,
    "articleId" integer REFERENCES "articles"("id") ON DELETE CASCADE,
    "parentId" integer REFERENCES "comments"("id") ON DELETE CASCADE,
    "isActive" boolean DEFAULT true,
    "likeCount" integer DEFAULT 0
);

-- Additional tables
CREATE TABLE IF NOT EXISTS "tags" (
    "id" serial PRIMARY KEY,
    "name" text UNIQUE NOT NULL,
    "slug" text UNIQUE NOT NULL,
    "color" text DEFAULT '#6B7280',
    "createdAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS "article_tags" (
    "id" serial PRIMARY KEY,
    "articleId" integer REFERENCES "articles"("id") ON DELETE CASCADE,
    "tagId" integer REFERENCES "tags"("id") ON DELETE CASCADE,
    "createdAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    UNIQUE("articleId", "tagId")
);

-- Basic indexes (PostgreSQL syntax)
CREATE INDEX IF NOT EXISTS "idx_users_email" ON "users"("email");
CREATE INDEX IF NOT EXISTS "idx_articles_slug" ON "articles"("slug");
CREATE INDEX IF NOT EXISTS "idx_articles_author" ON "articles"("authorId");
CREATE INDEX IF NOT EXISTS "idx_articles_category" ON "articles"("categoryId");
CREATE INDEX IF NOT EXISTS "idx_articles_published" ON "articles"("publishedAt");
CREATE INDEX IF NOT EXISTS "idx_categories_slug" ON "categories"("slug");
CREATE INDEX IF NOT EXISTS "idx_comments_article" ON "comments"("articleId");
CREATE INDEX IF NOT EXISTS "idx_comments_author" ON "comments"("authorId");

-- ===========================================
-- SAMPLE DATA (PostgreSQL compatible)
-- ===========================================

-- Insert admin user
INSERT INTO "users" ("id", "email", "name", "role", "isActive", "loyalty_points") 
VALUES ('admin-001', 'admin@sabq.sa', 'مدير النظام', 'ADMIN', true, 0)
ON CONFLICT ("email") DO NOTHING;

-- Insert basic categories
INSERT INTO "categories" ("name", "slug", "description") VALUES
('أخبار عامة', 'general-news', 'أخبار عامة ومتنوعة'),
('تقنية', 'technology', 'أخبار التكنولوجيا والتقنية'),
('رياضة', 'sports', 'الأخبار الرياضية'),
('اقتصاد', 'economy', 'الأخبار الاقتصادية'),
('صحة', 'health', 'أخبار الصحة والطب')
ON CONFLICT ("slug") DO NOTHING;

-- Insert basic tags
INSERT INTO "tags" ("name", "slug") VALUES
('عاجل', 'breaking'),
('حصري', 'exclusive'),
('متابعة', 'follow-up'),
('تحليل', 'analysis')
ON CONFLICT ("slug") DO NOTHING;

-- Insert sample article
INSERT INTO "articles" ("title", "slug", "content", "excerpt", "authorId", "categoryId", "status", "publishedAt", "metadata") 
VALUES (
    'مرحباً بكم في سبق الذكية الجديد',
    'welcome-to-new-sabq-ai',
    'هذا المقال التجريبي للتأكد من عمل النظام الجديد بشكل صحيح بعد النقل إلى Northflank. النظام الآن يعمل بكفاءة عالية مع قاعدة بيانات محسنة.',
    'مقال ترحيبي للتأكد من عمل النظام الجديد',
    'admin-001',
    1,
    'PUBLISHED',
    CURRENT_TIMESTAMP,
    '{"featured": true, "readingTime": 2}'::jsonb
) ON CONFLICT ("slug") DO NOTHING;

-- Link article with tags
INSERT INTO "article_tags" ("articleId", "tagId")
SELECT a.id, t.id 
FROM "articles" a, "tags" t 
WHERE a.slug = 'welcome-to-new-sabq-ai' AND t.slug = 'exclusive'
ON CONFLICT DO NOTHING;

-- Insert sample comment
INSERT INTO "comments" ("content", "authorId", "articleId")
SELECT 
    'مبروك على النظام الجديد! يبدو رائعاً',
    'admin-001',
    a.id
FROM "articles" a 
WHERE a.slug = 'welcome-to-new-sabq-ai'
ON CONFLICT DO NOTHING;

-- Update sequences (PostgreSQL syntax)
SELECT setval('categories_id_seq', COALESCE((SELECT MAX("id") FROM "categories"), 1));
SELECT setval('articles_id_seq', COALESCE((SELECT MAX("id") FROM "articles"), 1));
SELECT setval('comments_id_seq', COALESCE((SELECT MAX("id") FROM "comments"), 1));
SELECT setval('tags_id_seq', COALESCE((SELECT MAX("id") FROM "tags"), 1));
SELECT setval('article_tags_id_seq', COALESCE((SELECT MAX("id") FROM "article_tags"), 1));

COMMIT;

-- Success verification
DO $$
BEGIN
    RAISE NOTICE '==============================================';
    RAISE NOTICE 'SABQ Database - FIXED VERSION Completed!';
    RAISE NOTICE 'Tables: users, categories, articles, comments, tags';
    RAISE NOTICE 'Fixed PostgreSQL syntax errors';
    RAISE NOTICE 'Ready for production use!';
    RAISE NOTICE '==============================================';
END $$;
