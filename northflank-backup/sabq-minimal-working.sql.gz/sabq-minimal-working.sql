-- SABQ CMS - SIMPLE & WORKING BACKUP
-- Created: 2025-08-30
-- Purpose: Fix "relation does not exist" with MINIMAL approach
-- Strategy: Basic tables + Essential data only

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

-- Extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

BEGIN;

-- ===========================================
-- MINIMAL WORKING SCHEMA  
-- ===========================================

-- Users table (essential)
CREATE TABLE IF NOT EXISTS "users" (
    "id" text PRIMARY KEY DEFAULT gen_random_uuid()::text,
    "email" text UNIQUE NOT NULL,
    "name" text,
    "password" text,
    "image" text,
    "role" text DEFAULT 'USER',
    "createdAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "isActive" boolean DEFAULT true
);

-- Categories table
CREATE TABLE IF NOT EXISTS "categories" (
    "id" serial PRIMARY KEY,
    "name" text NOT NULL,
    "slug" text UNIQUE NOT NULL,
    "description" text,
    "color" text DEFAULT '#3B82F6',
    "createdAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "isActive" boolean DEFAULT true
);

-- Articles table
CREATE TABLE IF NOT EXISTS "articles" (
    "id" serial PRIMARY KEY,
    "title" text NOT NULL,
    "content" text,
    "excerpt" text,
    "slug" text UNIQUE NOT NULL,
    "featuredImage" text,
    "publishedAt" timestamp(3),
    "createdAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "authorId" text REFERENCES "users"("id") ON DELETE CASCADE,
    "categoryId" integer REFERENCES "categories"("id") ON DELETE SET NULL,
    "status" text DEFAULT 'DRAFT',
    "viewCount" integer DEFAULT 0,
    "isActive" boolean DEFAULT true,
    "isFeatured" boolean DEFAULT false
);

-- Comments table
CREATE TABLE IF NOT EXISTS "comments" (
    "id" serial PRIMARY KEY,
    "content" text NOT NULL,
    "createdAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" timestamp(3) DEFAULT CURRENT_TIMESTAMP,
    "authorId" text REFERENCES "users"("id") ON DELETE CASCADE,
    "articleId" integer REFERENCES "articles"("id") ON DELETE CASCADE,
    "isActive" boolean DEFAULT true
);

-- Basic indexes
CREATE INDEX IF NOT EXISTS "idx_users_email" ON "users"("email");
CREATE INDEX IF NOT EXISTS "idx_articles_slug" ON "articles"("slug");
CREATE INDEX IF NOT EXISTS "idx_articles_author" ON "articles"("authorId");
CREATE INDEX IF NOT EXISTS "idx_categories_slug" ON "categories"("slug");

-- ===========================================
-- SAMPLE DATA (for testing)
-- ===========================================

-- Insert admin user
INSERT INTO "users" ("id", "email", "name", "role", "isActive") 
VALUES ('admin-001', 'admin@sabq.sa', 'مدير النظام', 'ADMIN', true)
ON CONFLICT ("email") DO NOTHING;

-- Insert basic categories
INSERT INTO "categories" ("name", "slug", "description") VALUES
('أخبار عامة', 'general-news', 'أخبار عامة ومتنوعة'),
('تقنية', 'technology', 'أخبار التكنولوجيا والتقنية'),
('رياضة', 'sports', 'الأخبار الرياضية')
ON CONFLICT ("slug") DO NOTHING;

-- Insert sample article
INSERT INTO "articles" ("title", "slug", "content", "authorId", "categoryId", "status", "publishedAt") 
VALUES (
    'مرحباً بكم في سبق الذكية',
    'welcome-to-sabq-ai',
    'هذا المقال التجريبي للتأكد من عمل النظام بشكل صحيح.',
    'admin-001',
    1,
    'PUBLISHED',
    CURRENT_TIMESTAMP
) ON CONFLICT ("slug") DO NOTHING;

-- Update sequences
SELECT setval('categories_id_seq', COALESCE((SELECT MAX("id") FROM "categories"), 1));
SELECT setval('articles_id_seq', COALESCE((SELECT MAX("id") FROM "articles"), 1));
SELECT setval('comments_id_seq', COALESCE((SELECT MAX("id") FROM "comments"), 1));

COMMIT;

-- Verification
DO $$
BEGIN
    RAISE NOTICE 'SABQ Database setup completed successfully!';
    RAISE NOTICE 'Tables: users, categories, articles, comments';
    RAISE NOTICE 'Ready for production use.';
END $$;
